<?php
header('Content-Type: text/html; charset=utf-8');
if ($_REQUEST['fecha']=='01/01/2019')
{
  echo "Estos son de la fecha 01/01/2019<br>";
  echo "Feliz anno!!!!!<br>";
  echo "Feliz anno!!!!!<br>";
  echo "Feliz anno!!!!!<br>";
  echo "Feliz anno!!!!!<br>";
  echo "Feliz anno!!!!!<br>";
  echo "Feliz anno!!!!!<br>";
  echo "Feliz anno!!!!!<br>";
  echo "Feliz anno!!!!!<br>";
  echo "Feliz anno!!!!!<br>";
  echo "Feliz anno!!!!!<br>";
  echo "Feliz anno!!!!!<br>";
}
if ($_REQUEST['fecha']=='02/01/2019')
{
  echo "Estos son de la fecha 02/01/2019<br>";
  echo "Feliz anno nuevo gente!!!<br>";
  echo "Feliz anno nuevo gente!!!<br>";
  echo "Feliz anno nuevo gente!!!<br>";
  echo "Feliz anno nuevo gente!!!<br>";
  echo "Feliz anno nuevo gente!!!<br>";
  echo "Feliz anno nuevo gente!!!<br>";
  echo "Feliz anno nuevo gente!!!<br>";
  echo "Feliz anno nuevo gente!!!<br>";
}
if ($_REQUEST['fecha']=='03/01/2019')
{
  echo "Estos son de la fecha 03/01/2019<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
  echo "Ya estamos en otro anno<br>";
}
?>