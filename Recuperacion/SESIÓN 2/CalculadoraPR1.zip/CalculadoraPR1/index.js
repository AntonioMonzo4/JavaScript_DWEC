const displayValorAnterior = document.getElementById('valor-anterior');
const displayValorActual   = document.getElementById('valor-actual');
const botonesNumeros       = "<selector>";
const botonesOperadores    = "<selector>";
const botonBorrar          = "<selector>";
const botonBorrarTodo      = "<selector>";

const display              = new Display(displayValorAnterior, displayValorActual);

//asociar función al evento click del botón borrar
//display.borrar()

//asociar función al evento click del botón borrar todo
//display.borrarTodo()


//asociar función al evento click de cada elemento de tipo número
//display.agregarNumero(numero);

//asociar función al evento click de cada elemento de tipo operador
//display.realizarCalculo(tipo);
